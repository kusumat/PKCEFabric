define("userForm2Controller", {
    //Type your controller code here 
});
define("Form2ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_ja5b030c56e64a298605ecd42f44356a: function AS_Button_ja5b030c56e64a298605ecd42f44356a(eventobject) {
        var self = this;
        return googleOauth.call(this);
    }
});
define("Form2Controller", ["userForm2Controller", "Form2ControllerActions"], function() {
    var controller = require("userForm2Controller");
    var controllerActions = ["Form2ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
