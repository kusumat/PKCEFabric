define("browser", function() {
    return function(controller) {
        function addWidgetsbrowser() {
            this.setDefaultUnit(voltmx.flex.DP);
            var Browser0g4a4d092f0674a = new voltmx.ui.Browser({
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "380dp",
                "id": "Browser0g4a4d092f0674a",
                "isVisible": true,
                "left": "40dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "www.google.com",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "80dp",
                "width": "63.69%",
                "zIndex": 1
            }, {}, {});
            this.compInstData = {}
            this.add(Browser0g4a4d092f0674a);
        };
        return [{
            "addWidgets": addWidgetsbrowser,
            "enabledForIdleTimeout": false,
            "id": "browser",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "browserLic"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});