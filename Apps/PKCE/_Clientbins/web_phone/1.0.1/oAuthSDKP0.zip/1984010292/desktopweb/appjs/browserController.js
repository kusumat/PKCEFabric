define("userbrowserController", {
    //Type your controller code here 
});
define("browserControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("browserController", ["userbrowserController", "browserControllerActions"], function() {
    var controller = require("userbrowserController");
    var controllerActions = ["browserControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
