define("Form1", function() {
    return function(controller) {
        function addWidgetsForm1() {
            this.setDefaultUnit(voltmx.flex.DP);
            var FlexContainer0eddbcfde61654d = new voltmx.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "FlexContainer0eddbcfde61654d",
                "isVisible": true,
                "layoutType": voltmx.flex.FREE_FORM,
                "left": "6dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "87dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "browserLic"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0eddbcfde61654d.setDefaultUnit(voltmx.flex.DP);
            FlexContainer0eddbcfde61654d.add();
            var Button0f028ebecfb8c4e = new voltmx.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0f028ebecfb8c4e",
                "isVisible": true,
                "left": "228dp",
                "onClick": controller.AS_Button_g2f548b635b44edaa66c1ac1d3f3666a,
                "skin": "defBtnNormal",
                "text": "Button",
                "top": "197dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(FlexContainer0eddbcfde61654d, Button0f028ebecfb8c4e);
        };
        return [{
            "addWidgets": addWidgetsForm1,
            "enabledForIdleTimeout": false,
            "id": "Form1",
            "layoutType": voltmx.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "browserLic"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": voltmx.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});