define("userForm1Controller", {
    //Type your controller code here 
});
define("Form1ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_g2f548b635b44edaa66c1ac1d3f3666a: function AS_Button_g2f548b635b44edaa66c1ac1d3f3666a(eventobject) {
        var self = this;
        var ntf = new voltmx.mvc.Navigation({
            "appName": "oAuthSDKP0",
            "friendlyName": "Form2"
        });
        ntf.navigate();
    }
});
define("Form1Controller", ["userForm1Controller", "Form1ControllerActions"], function() {
    var controller = require("userForm1Controller");
    var controllerActions = ["Form1ControllerActions"];
    return voltmx.visualizer.mixinControllerActions(controller, controllerActions);
});
